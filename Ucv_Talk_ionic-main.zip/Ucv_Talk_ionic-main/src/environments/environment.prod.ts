export const environment = {
  production: true,
  socketIoConfig: { 
    url: 'localhost:3000', 
    options: {}
  }
};
