export interface ProfesionalResponse {
    Id_ProfesRegis: number;
    Nombre:         string;
    Apellido:       string;
    Correo:         string;
    Especialidad:   string;
    Usuario:        string;
    Contra:         string;
}