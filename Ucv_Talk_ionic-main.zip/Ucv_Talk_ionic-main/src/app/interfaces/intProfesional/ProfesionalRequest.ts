export interface ProfesionalRequest {
    Nombre:         string;
    Apellido:       string;
    Correo:         string;
    Especialidad:   string;
    Usuario:        string;
    Contra:         string;
}