export interface ProfesionalLogin{
    Usuario: string;
    Contra: string;
}