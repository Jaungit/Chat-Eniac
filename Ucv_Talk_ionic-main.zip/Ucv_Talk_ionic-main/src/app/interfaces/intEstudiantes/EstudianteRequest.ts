export interface EstudianteRequest {
    idUcv_estu:          string;
    Correo?:             string;
    Usuario:             string;
    Contra:              string;
    Genero?:             number;
}