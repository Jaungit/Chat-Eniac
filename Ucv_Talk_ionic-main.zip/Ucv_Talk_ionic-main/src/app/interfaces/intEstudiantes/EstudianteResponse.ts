export interface EstudianteResponse {
    Id_EstudianteRegis: number;
    idUcv_estu:          string;
    Correo?:             string;
    Usuario:             string;
    Contra:              string;
    Genero?:             number;
}