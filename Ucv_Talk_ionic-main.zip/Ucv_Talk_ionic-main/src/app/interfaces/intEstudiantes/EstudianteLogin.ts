export interface EstudianteLogin{
    Usuario: string;
    Contra: string;
}