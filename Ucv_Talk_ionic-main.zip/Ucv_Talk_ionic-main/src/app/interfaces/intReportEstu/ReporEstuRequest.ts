export interface ReporEstuRequest{
    Asunto: string;
    Descripcion: string;
    Id_EstudianteRegis: number;
}