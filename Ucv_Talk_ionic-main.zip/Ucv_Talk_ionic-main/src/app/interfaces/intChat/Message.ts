export interface Message {
    text: string;
    from: string;
    created: Date;
  }
  