export interface UserData {
    user: string;
    event: string;
  }