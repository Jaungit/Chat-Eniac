export interface CalificaProfeResponse {
    Id_Califica: number;
    Id_EstudianteRegis?: number;
    Id_ProfesRegis?: number;
    Calificacion: number;
}