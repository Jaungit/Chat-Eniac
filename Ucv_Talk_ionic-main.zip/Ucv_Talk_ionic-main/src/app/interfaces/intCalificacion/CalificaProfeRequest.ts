export interface CalificaProfeRequest {
    Id_EstudianteRegis?: number;
    Id_ProfesRegis?: number;
    Calificacion: number;
}