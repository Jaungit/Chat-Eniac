import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tab-estu',
  templateUrl: './tab-estu.page.html',
  styleUrls: ['./tab-estu.page.scss'],
})
export class TabEstuPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
